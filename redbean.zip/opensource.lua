Write('This Lua Server Page is stored in ZIP\r\n')
Write('as normal Lua code that is compressed\r\n')

mymodule = require "mymodule"
sqlite3 = require "lsqlite3"
json = require "json"

-- /.init.lua is loaded at startup in redbean's main process
HidePath('/usr/share/zoneinfo/')
HidePath('/usr/share/ssl/')

-- open a browser tab using explorer/open/xdg-open
-- LaunchBrowser('/tool/net/demo/index.html')

-- sql database (see sql.lua)
-- db = sqlite3.open('chan.db')
db = sqlite3.open_memory()

db:exec[[
<<create_boards_sql>>;
]]

-- this intercepts all requests if it's defined
function OnHttpRequest()
   if HasParam('magic') then
      Write('<p>\r\n')
      Write('OnHttpRequest() has intercepted your request<br>\r\n')
      Write('because you specified the magic parameter\r\n')
      Write('<pre>\r\n')
      Write(EscapeHtml(LoadAsset('/.init.lua')))
      Write('</pre>\r\n')
   else
      Route() -- this asks redbean to do the default thing
   end
   SetHeader('Server', 'redbean!')
end

Write('This Lua Server Page is stored in ZIP\r\n')
Write('as compressed byte code, see luac.com and net.mk\r\n')

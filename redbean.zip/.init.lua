mymodule = require "mymodule"
sqlite3 = require "lsqlite3"
json = require "json"

-- /.init.lua is loaded at startup in redbean's main process
HidePath('/usr/share/zoneinfo/')
HidePath('/usr/share/ssl/')

-- open a browser tab using explorer/open/xdg-open
-- LaunchBrowser('/tool/net/demo/index.html')

-- sql database (see sql.lua)
-- db = sqlite3.open('chan.db')
db = sqlite3.open_memory()

db:exec[[
CREATE TABLE IF NOT EXISTS boards (
  id INTEGER PRIMARY KEY,
  name TEXT,
  description TEXT,
  created_user TEXT,
  created_dttm TEXT,
  updated_user TEXT,
  updated_dttm TEXT,
  delete_flg TEXT
);
CREATE TABLE IF NOT EXISTS topics (
  id INTEGER PRIMARY KEY,
  name TEXT,
  description TEXT,
  board_id INTEGER,
  created_user TEXT,
  created_dttm TEXT,
  updated_user TEXT,
  updated_dttm TEXT,
  delete_flg TEXT
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY,
  name TEXT,
  description TEXT,
  topic_id INTEGER,
  parent_post_id INTEGER,
  created_user TEXT,
  created_dttm TEXT,
  updated_user TEXT,
  updated_dttm TEXT,
  delete_flg TEXT
);
]]

-- this intercepts all requests if it's defined
function OnHttpRequest()
   if HasParam('magic') then
      Write('<p>\r\n')
      Write('OnHttpRequest() has intercepted your request<br>\r\n')
      Write('because you specified the magic parameter\r\n')
      Write('<pre>\r\n')
      Write(EscapeHtml(LoadAsset('/.init.lua')))
      Write('</pre>\r\n')
   else
      Route() -- this asks redbean to do the default thing
   end
   SetHeader('Server', 'redbean!')
end
